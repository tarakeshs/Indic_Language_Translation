from flask import Blueprint, request, jsonify
from app.models.google_translate import translate_with_google, preprocess_text
from app.models.indictrans import translate_with_indictrans

main = Blueprint('main', __name__)

@main.route('/translate', methods=['POST'])
def translate_route():
    data = request.json
    text = preprocess_text(data.get('text'))  # Preprocess the text
    target_language = data.get('target_language')
    model_flag = data.get('model')  # Use this flag to switch models

    if not text or not target_language or not model_flag:
        return jsonify({"error": "Missing required parameters"}), 400

    try:
        if model_flag == 'google':
            translated_text = translate_with_google(text, target_language)
        elif model_flag == 'indictrans':
            translated_text = translate_with_indictrans(text, target_language)
        else:
            return jsonify({"error": "Invalid model flag"}), 400

        return jsonify({"translated_text": translated_text}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
