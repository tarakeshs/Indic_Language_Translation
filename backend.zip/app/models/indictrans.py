from transformers import AutoTokenizer, AutoModel
import torch

# Load the tokenizer and model for Indic-BERT
tokenizer = AutoTokenizer.from_pretrained("ai4bharat/indic-bert")
model = AutoModel.from_pretrained("ai4bharat/indic-bert")

def preprocess_text(text: str) -> str:
    """Preprocess the text by applying common cleaning steps."""
    # Add text preprocessing logic, such as lowercasing, removing special characters, etc.
    text = text.lower()
    return text

def translate_with_indictrans(text: str, target_language: str) -> str:
    """Generate embeddings using Indic-BERT for translation purposes."""
    
    try:
        # Preprocess the text
        text = preprocess_text(text)
        print(f"Preprocessed Text: {text}")  # Debug
        
        # Tokenize the input text
        inputs = tokenizer(text, return_tensors="pt")
        print(f"Tokenized Input: {inputs}")  # Debug
        
        # Get model outputs (hidden states or embeddings)
        outputs = model(**inputs)
        embeddings = outputs.last_hidden_state
        print(f"Model Outputs: {embeddings}")  # Debug

        # Return or process the embeddings
        return embeddings  # Update this to return a proper translation
    except Exception as e:
        print(f"Error: {str(e)}")  # Capture the error
        return f"Error: {str(e)}"
